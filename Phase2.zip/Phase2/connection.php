<?php
/* Process the form data to get the course ID and access the database to find the information.	$Total = 0;
    $username = $_POST['username']; 
	$password = $_POST['password']; */



$host = "localhost";
$db_name = "ktcs";
$username = "cisc332"; // use your own username and password if different from mine
$password = "cisc332";

try {
    $dbh = new mysqli($host,$username,$password, $db_name);

}
 /*
try {
   Create a connection with the database $dbh = null;
   $dbh = new PDO('mysql:host=localhost;dbname=cisc332', 'root', 'Wanyoike96!');*/

   /* Turn on error checking  
   $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


   
die();

} */catch (Exception $e) {
      echo $e->getMessage();
      
}

?>
